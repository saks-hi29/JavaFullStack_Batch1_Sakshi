public class Customer {
    String name;

    Customer(String name) {
        this.name = name;
    }

    void displayCustomerName() {
        System.out.println("Customer Name: " + name);
    }

    public static void main(String[] args) {
        Customer c = new Customer("VerizonUser");
        c.displayCustomerName();
    }
}